/* GreenGlo AI Chat Widget
   Add to your website with one script tag. See README for instructions. */

(function () {
  const BACKEND_URL = 'https://greenglo-chatbot.onrender.com'; // UPDATE after deploying to Render
  const sessionId = 'gg-' + Math.random().toString(36).substr(2, 12) + '-' + Date.now();

  /* ── Styles ── */
  const style = document.createElement('style');
  style.textContent = `
    #gg-chat-bubble {
      position: fixed; bottom: 24px; right: 24px; z-index: 9999;
      width: 58px; height: 58px; border-radius: 50%;
      background: #1a6b3a; border: none; cursor: pointer;
      box-shadow: 0 4px 16px rgba(0,0,0,0.18);
      display: flex; align-items: center; justify-content: center;
      transition: transform 0.2s;
    }
    #gg-chat-bubble:hover { transform: scale(1.08); }
    #gg-chat-bubble svg { width: 28px; height: 28px; fill: white; }
    #gg-chat-bubble .gg-notif {
      position: absolute; top: 2px; right: 2px;
      width: 14px; height: 14px; border-radius: 50%;
      background: #e63946; border: 2px solid white;
      display: none;
    }
    #gg-chat-window {
      position: fixed; bottom: 96px; right: 24px; z-index: 9999;
      width: 360px; max-width: calc(100vw - 32px);
      background: #fff; border-radius: 16px;
      box-shadow: 0 8px 40px rgba(0,0,0,0.18);
      display: none; flex-direction: column;
      overflow: hidden; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      border: 1px solid rgba(0,0,0,0.08);
    }
    #gg-chat-window.open { display: flex; }
    #gg-chat-header {
      background: #1a6b3a; color: white;
      padding: 14px 16px; display: flex; align-items: center; gap: 10px;
    }
    #gg-chat-header .gg-avatar {
      width: 36px; height: 36px; border-radius: 50%;
      background: rgba(255,255,255,0.2);
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; flex-shrink: 0;
    }
    #gg-chat-header .gg-title { font-weight: 600; font-size: 15px; }
    #gg-chat-header .gg-subtitle { font-size: 12px; opacity: 0.85; margin-top: 1px; }
    #gg-chat-header .gg-close {
      margin-left: auto; background: none; border: none;
      color: white; cursor: pointer; font-size: 22px; line-height: 1;
      opacity: 0.8; padding: 0 4px;
    }
    #gg-chat-header .gg-close:hover { opacity: 1; }
    #gg-messages {
      flex: 1; overflow-y: auto; padding: 16px;
      min-height: 280px; max-height: 380px;
      display: flex; flex-direction: column; gap: 10px;
      background: #f7f9f7;
    }
    .gg-msg {
      max-width: 82%; padding: 10px 13px;
      border-radius: 16px; font-size: 14px; line-height: 1.5;
      word-break: break-word;
    }
    .gg-msg.bot {
      background: #fff; color: #1a1a1a; align-self: flex-start;
      border-bottom-left-radius: 4px;
      box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    }
    .gg-msg.user {
      background: #1a6b3a; color: white; align-self: flex-end;
      border-bottom-right-radius: 4px;
    }
    .gg-typing {
      display: flex; gap: 4px; align-items: center;
      padding: 10px 13px; background: #fff; border-radius: 16px;
      border-bottom-left-radius: 4px; align-self: flex-start;
      box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    }
    .gg-typing span {
      width: 7px; height: 7px; border-radius: 50%;
      background: #1a6b3a; opacity: 0.5;
      animation: gg-bounce 1s infinite;
    }
    .gg-typing span:nth-child(2) { animation-delay: 0.2s; }
    .gg-typing span:nth-child(3) { animation-delay: 0.4s; }
    @keyframes gg-bounce {
      0%, 80%, 100% { transform: translateY(0); opacity: 0.5; }
      40% { transform: translateY(-5px); opacity: 1; }
    }
    #gg-chat-input-row {
      display: flex; gap: 8px; padding: 12px;
      background: #fff; border-top: 1px solid #f0f0f0;
    }
    #gg-chat-input {
      flex: 1; border: 1.5px solid #e0e0e0; border-radius: 24px;
      padding: 9px 14px; font-size: 14px; outline: none;
      font-family: inherit; resize: none; height: 38px;
      transition: border-color 0.2s;
    }
    #gg-chat-input:focus { border-color: #1a6b3a; }
    #gg-send-btn {
      width: 38px; height: 38px; border-radius: 50%;
      background: #1a6b3a; border: none; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0; transition: background 0.2s;
    }
    #gg-send-btn:hover { background: #145530; }
    #gg-send-btn svg { width: 18px; height: 18px; fill: white; }
    #gg-whatsapp-fallback {
      text-align: center; padding: 8px 12px 12px;
      font-size: 12px; color: #888; background: #fff;
    }
    #gg-whatsapp-fallback a {
      color: #1a6b3a; text-decoration: none; font-weight: 600;
    }
    #gg-whatsapp-fallback a:hover { text-decoration: underline; }
  `;
  document.head.appendChild(style);

  /* ── HTML ── */
  const container = document.createElement('div');
  container.innerHTML = `
    <button id="gg-chat-bubble" aria-label="Chat with GreenGlo">
      <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
      <div class="gg-notif" id="gg-notif"></div>
    </button>
    <div id="gg-chat-window" role="dialog" aria-label="GreenGlo chat">
      <div id="gg-chat-header">
        <div class="gg-avatar">🌿</div>
        <div>
          <div class="gg-title">GreenGlo Assistant</div>
          <div class="gg-subtitle">Instant quotes &amp; booking</div>
        </div>
        <button class="gg-close" id="gg-close-btn" aria-label="Close chat">&#x2715;</button>
      </div>
      <div id="gg-messages"></div>
      <div id="gg-chat-input-row">
        <input id="gg-chat-input" type="text" placeholder="Type your message..." autocomplete="off" />
        <button id="gg-send-btn" aria-label="Send">
          <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
        </button>
      </div>
      <div id="gg-whatsapp-fallback">
        Prefer to chat directly?
        <a href="https://api.whatsapp.com/send?phone=447827784204&text=Hello%20GreenGlo%2C%20I%27d%20like%20a%20quote" target="_blank">Message us on WhatsApp</a>
      </div>
    </div>
  `;
  document.body.appendChild(container);

  /* ── Elements ── */
  const bubble = document.getElementById('gg-chat-bubble');
  const window_ = document.getElementById('gg-chat-window');
  const closeBtn = document.getElementById('gg-close-btn');
  const messagesEl = document.getElementById('gg-messages');
  const input = document.getElementById('gg-chat-input');
  const sendBtn = document.getElementById('gg-send-btn');
  const notif = document.getElementById('gg-notif');

  let isOpen = false;
  let greeted = false;

  /* ── Helpers ── */
  function addMessage(text, sender) {
    const el = document.createElement('div');
    el.className = 'gg-msg ' + sender;
    el.textContent = text;
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return el;
  }

  function showTyping() {
    const el = document.createElement('div');
    el.className = 'gg-typing';
    el.id = 'gg-typing-indicator';
    el.innerHTML = '<span></span><span></span><span></span>';
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function removeTyping() {
    const t = document.getElementById('gg-typing-indicator');
    if (t) t.remove();
  }

  async function sendMessage(text) {
    if (!text.trim()) return;
    addMessage(text, 'user');
    input.value = '';
    input.disabled = true;
    sendBtn.disabled = true;
    showTyping();

    try {
      const res = await fetch(BACKEND_URL + '/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, sessionId }),
      });
      const data = await res.json();
      removeTyping();
      addMessage(data.reply || 'Sorry, something went wrong. Please try again.', 'bot');
    } catch (e) {
      removeTyping();
      addMessage('Sorry, I\'m having trouble connecting. Please WhatsApp us directly at 07827 784204.', 'bot');
    }

    input.disabled = false;
    sendBtn.disabled = false;
    input.focus();
  }

  async function openChat() {
    isOpen = true;
    window_.classList.add('open');
    bubble.setAttribute('aria-expanded', 'true');
    notif.style.display = 'none';

    if (!greeted) {
      greeted = true;
      showTyping();
      await new Promise(r => setTimeout(r, 900));
      removeTyping();
      addMessage('Hi! 👋 Welcome to GreenGlo Cleaners. I can give you an instant quote and get you booked in today. What type of cleaning do you need?', 'bot');
    }
    input.focus();
  }

  function closeChat() {
    isOpen = false;
    window_.classList.remove('open');
    bubble.setAttribute('aria-expanded', 'false');
  }

  /* ── Events ── */
  bubble.addEventListener('click', () => isOpen ? closeChat() : openChat());
  closeBtn.addEventListener('click', closeChat);
  sendBtn.addEventListener('click', () => sendMessage(input.value));
  input.addEventListener('keydown', e => { if (e.key === 'Enter') sendMessage(input.value); });

  /* ── Auto-open triggers ── */
  // Show notification dot after 8 seconds if user hasn't opened chat
  setTimeout(() => {
    if (!isOpen && !greeted) {
      notif.style.display = 'block';
    }
  }, 8000);

  /* ── Replace WhatsApp links ── */
  // Replace all WhatsApp quote/booking links on the page with chat opener
  document.querySelectorAll('a[href*="api.whatsapp.com"]').forEach(link => {
    const href = link.getAttribute('href') || '';
    // Keep the direct WhatsApp link in the fallback section, replace others
    if (!link.closest('#gg-whatsapp-fallback')) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        openChat();
      });
    }
  });

  // Expose openChat globally so you can call window.GreenGloChat.open() from anywhere
  window.GreenGloChat = { open: openChat, close: closeChat };
})();
