# GreenGlo AI Chatbot — Setup Guide

Follow these steps carefully. Each step is short. You've got this!

---

## PART 1 — Get a free API key from Anthropic

1. Go to https://console.anthropic.com
2. Sign up for a free account
3. Click "API Keys" in the left menu
4. Click "Create Key", give it a name like "GreenGlo Chatbot"
5. COPY the key — it starts with "sk-ant-..." — paste it in Notepad for now
   ⚠️ You only see it once!

---

## PART 2 — Add the backend files to your GitHub repo

You need to add 3 files to your GitHub repo:
- server.js
- package.json
- widget.js  (this one goes in your website root, NOT in a subfolder)

HOW TO UPLOAD TO GITHUB:
1. Go to https://github.com/greenglocleaning/greenglocleaningco
2. Click "Add file" → "Upload files"
3. Drag in server.js and package.json
4. Click "Commit changes"
5. Do the same again for widget.js

---

## PART 3 — Deploy the backend on Render (free)

1. Go to https://render.com and sign up (free)
2. Click "New +" → "Web Service"
3. Connect your GitHub account when asked
4. Select your repo: greenglocleaningco
5. Fill in these settings:
   - Name: greenglo-chatbot
   - Environment: Node
   - Build Command: npm install
   - Start Command: node server.js
   - Plan: Free
6. Click "Advanced" → "Add Environment Variable"
   - Key:   ANTHROPIC_API_KEY
   - Value: [paste your key from Part 1]
7. Click "Create Web Service"
8. Wait 2-3 minutes for it to deploy
9. COPY your Render URL — it looks like: https://greenglo-chatbot.onrender.com

---

## PART 4 — Update widget.js with your Render URL

1. Open widget.js in GitHub
2. On line 8, find:
   const BACKEND_URL = 'https://greenglo-chatbot.onrender.com';
3. Make sure it matches YOUR Render URL exactly
4. Save/commit the change

---

## PART 5 — Add the chat widget to your HTML pages

Add this ONE line just before the closing </body> tag in EACH of these files:
- index.html
- services.html
- commercial.html
- airbnb.html
- greengloclub.html
- gallery.html

The line to add:
<script src="/widget.js"></script>

HOW TO EDIT IN GITHUB:
1. Open the file (e.g. index.html)
2. Click the pencil icon (Edit)
3. Press Ctrl+F (or Cmd+F on Mac), search for: </body>
4. Click just before </body> and add a new line
5. Paste: <script src="/widget.js"></script>
6. Click "Commit changes"

---

## PART 6 — Test it!

1. Go to https://greenglocleaningco.com
2. You should see a green chat bubble in the bottom-right corner
3. Click it — say "I need a quote for a deep clean"
4. The AI should respond and walk you through it

---

## TROUBLESHOOTING

Chat bubble not showing?
→ Check that widget.js is in the root of your repo (not in a subfolder)
→ Check the script tag is just before </body>

AI not responding?
→ Go to your Render dashboard and check the logs
→ Make sure your ANTHROPIC_API_KEY is set correctly

Getting "connecting" error?
→ Free Render servers sleep after 15 mins. First message after a sleep takes ~30 seconds.
→ To fix this, upgrade to Render's $7/mo Starter plan.

---

## COSTS

- Anthropic API: ~£10-20/month for typical usage
- Render hosting: Free (or $7/mo to remove cold starts)
- Total: Under £25/month

---

## NEED HELP?

If you get stuck on any step, just message Claude and paste the error you're seeing.
