const express = require('express');
const cors = require('cors');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
app.use(cors());
app.use(express.json());

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SYSTEM_PROMPT = `You are GreenGlo's friendly AI assistant for GreenGlo Cleaners, a premium eco-friendly cleaning company based in London.

YOUR JOB: Help customers get an instant quote and book a cleaning service online.

ABOUT GREENGLO:
- Eco-friendly, non-toxic, pet-safe cleaning products
- BICSc registered, fully insured, background-checked cleaners
- Serving London, Kent, and Essex
- Starting from £18/hour
- Available weekends and holidays
- Members get priority booking, £300 in credits via GreenGlo Club

SERVICES & PRICING:
- Domestic/Regular Cleaning: from £18/hr (minimum 2 hours)
- Deep Cleaning: from £180 (3-4 bed home)
- End of Tenancy: from £150 (studio), £200 (1 bed), £250 (2 bed), £300 (3 bed)
- After Builders Clean: from £250
- Carpet Cleaning: from £60 per room
- Office/Commercial Cleaning: custom quote
- Airbnb/Holiday Let Cleaning: from £60 per clean
- Emergency/Same-day: available, call for pricing

BOOKING FLOW - follow these steps in order:
1. Greet warmly and ask what type of cleaning they need
2. Ask for their postcode to confirm coverage
3. Ask for the property size (studio / 1 bed / 2 bed / 3 bed / larger / office)
4. Ask for their preferred date and time
5. Give them a price estimate based on the above
6. Ask for their name and phone number to confirm the booking
7. Tell them: "Great! I'll confirm your booking now. You'll receive a confirmation by WhatsApp/SMS shortly. To secure your booking, please complete payment here: [BOOKING_LINK]"

COVERAGE CHECK:
- London postcodes: E, EC, N, NW, SE, SW, W, WC, BR, CR, DA, EN, HA, IG, KT, RM, SM, TW, UB, WD — COVERED
- Kent postcodes: ME, TN, CT, DA — COVERED  
- Essex postcodes: CM, CO, IG, RM, SS — COVERED
- Outside these areas: apologise and say you don't currently cover their area, offer to add them to a waitlist

TONE: Friendly, warm, professional. Keep messages short and conversational — one or two sentences max per reply. Use the customer's name once you have it.

IMPORTANT: 
- Never make up prices not listed above
- For commercial jobs over £500 or unusual requests, say "Let me get our team to give you a personalised quote — what's the best number to reach you on?"
- If they ask about something unrelated to cleaning, politely redirect: "I'm just here to help with cleaning bookings — can I help you get a quote today?"
- The booking payment link is: https://greenglocleaningco.com/services.html`;

const conversationHistory = new Map();

app.post('/chat', async (req, res) => {
  try {
    const { message, sessionId } = req.body;

    if (!message || !sessionId) {
      return res.status(400).json({ error: 'Missing message or sessionId' });
    }

    if (!conversationHistory.has(sessionId)) {
      conversationHistory.set(sessionId, []);
    }

    const history = conversationHistory.get(sessionId);
    history.push({ role: 'user', content: message });

    // Keep last 20 messages to avoid token limits
    const trimmedHistory = history.slice(-20);

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: SYSTEM_PROMPT,
      messages: trimmedHistory,
    });

    const reply = response.content[0].text;
    history.push({ role: 'assistant', content: reply });

    // Clean up old sessions after 2 hours
    setTimeout(() => conversationHistory.delete(sessionId), 7200000);

    res.json({ reply });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`GreenGlo chatbot running on port ${PORT}`));
